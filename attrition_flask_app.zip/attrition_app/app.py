"""
Employee Attrition Prediction - Flask App
==========================================
Serves the CatBoost model trained in employee_attrition.ipynb.

IMPORTANT - PLEASE READ BEFORE TRUSTING PREDICTIONS
-----------------------------------------------------
This version predicts directly on RAW (unscaled) feature values, with no
StandardScaler applied. Your notebook actually trained CatBoost on scaled
data (`X_train = scaler.fit_transform(x_train)`), so skipping scaling here
means predictions may not match what the notebook produced. This is a
deliberate simplification per request - if you want more accurate
predictions later, export the scaler from your notebook and reintroduce it.

Also, because the model was fit on a plain numpy array (not a DataFrame),
CatBoost has no memory of the original column names or order (its
`feature_names_` are just '0', '1', '2', ...). The FEATURE_ORDER and
ENCODING MAPS below are reconstructed from the public Kaggle dataset
description and from LabelEncoder's default (alphabetical) behavior -
they are NOT verified against your actual training run. Please run the
verification cell in the README before trusting predictions in production.
"""

import os
import pickle
import numpy as np
from flask import Flask, render_template, request

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "best_catboost_model.pkl")

# ---------------------------------------------------------------------------
# 1. Load model
# ---------------------------------------------------------------------------
with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

# ---------------------------------------------------------------------------
# 2. Feature order the model expects (best-effort reconstruction - verify!)
# ---------------------------------------------------------------------------
FEATURE_ORDER = [
    "Age",
    "Gender",
    "Years at Company",
    "Job Role",
    "Monthly Income",
    "Work-Life Balance",
    "Job Satisfaction",
    "Performance Rating",
    "Number of Promotions",
    "Overtime",
    "Distance from Home",
    "Education Level",
    "Marital Status",
    "Number of Dependents",
    "Job Level",
    "Company Size",
    "Company Tenure",
    "Remote Work",
    "Leadership Opportunities",
    "Innovation Opportunities",
    "Company Reputation",
    "Employee Recognition",
    "Age_group",
]

# ---------------------------------------------------------------------------
# 3. Category -> integer maps, replicating sklearn LabelEncoder's default
#    behaviour (alphabetical sort of the unique string values -> 0..n-1).
# ---------------------------------------------------------------------------
ENCODINGS = {
    "Gender": {"Female": 0, "Male": 1},
    "Job Role": {
        "Education": 0,
        "Finance": 1,
        "Healthcare": 2,
        "Media": 3,
        "Technology": 4,
    },
    "Work-Life Balance": {"Excellent": 0, "Fair": 1, "Good": 2, "Poor": 3},
    "Job Satisfaction": {"High": 0, "Low": 1, "Medium": 2, "Very High": 3},
    "Performance Rating": {"Average": 0, "Below Average": 1, "High": 2, "Low": 3},
    "Overtime": {"No": 0, "Yes": 1},
    "Education Level": {
        "Bachelor's Degree": 0,
        "High School": 1,
        "Master's Degree": 2,
        "PhD": 3,
    },
    "Marital Status": {"Divorced": 0, "Married": 1, "Single": 2},
    "Job Level": {"Entry": 0, "Mid": 1, "Senior": 2},
    "Company Size": {"Large": 0, "Medium": 1, "Small": 2},
    "Remote Work": {"No": 0, "Yes": 1},
    "Leadership Opportunities": {"No": 0, "Yes": 1},
    "Innovation Opportunities": {"No": 0, "Yes": 1},
    "Company Reputation": {"Excellent": 0, "Fair": 1, "Good": 2, "Poor": 3},
    "Employee Recognition": {"High": 0, "Low": 1, "Medium": 2},
}

AGE_GROUP_ENCODING = {"adult": 0, "old": 1, "teen": 2, "too old": 3}

# What the model's 0/1 output means (Attrition: Left=0, Stayed=1 alphabetically)
TARGET_LABELS = {0: "Left", 1: "Stayed"}

# Options shown in the form's dropdowns (kept in a sensible display order,
# independent of the alphabetical order used internally for encoding)
FORM_OPTIONS = {
    "Gender": ["Male", "Female"],
    "Job Role": ["Technology", "Finance", "Healthcare", "Education", "Media"],
    "Work-Life Balance": ["Excellent", "Good", "Fair", "Poor"],
    "Job Satisfaction": ["Very High", "High", "Medium", "Low"],
    "Performance Rating": ["High", "Average", "Below Average", "Low"],
    "Overtime": ["No", "Yes"],
    "Education Level": ["High School", "Bachelor's Degree", "Master's Degree", "PhD"],
    "Marital Status": ["Single", "Married", "Divorced"],
    "Job Level": ["Entry", "Mid", "Senior"],
    "Company Size": ["Small", "Medium", "Large"],
    "Remote Work": ["No", "Yes"],
    "Leadership Opportunities": ["No", "Yes"],
    "Innovation Opportunities": ["No", "Yes"],
    "Company Reputation": ["Excellent", "Good", "Fair", "Poor"],
    "Employee Recognition": ["Low", "Medium", "High"],
}

NUMERIC_FIELDS = [
    ("Age", "Age", 18, 65, 30),
    ("Years at Company", "Years at Company", 0, 40, 5),
    ("Monthly Income", "Monthly Income ($)", 0, 50000, 5000),
    ("Number of Promotions", "Number of Promotions", 0, 10, 0),
    ("Distance from Home", "Distance from Home (miles)", 0, 100, 10),
    ("Number of Dependents", "Number of Dependents", 0, 10, 0),
    ("Company Tenure", "Company Tenure (years)", 0, 60, 5),
]


def compute_age_group(age: float) -> str:
    """Replicates: pd.cut(df['Age'], bins=[0,19,30,60,100],
    labels=['teen','adult','old','too old'])  (right-closed bins)."""
    if age <= 19:
        return "teen"
    elif age <= 30:
        return "adult"
    elif age <= 60:
        return "old"
    else:
        return "too old"


def build_feature_vector(form) -> np.ndarray:
    age = float(form["Age"])
    age_group = compute_age_group(age)

    row = {}
    for field, _, *_rest in NUMERIC_FIELDS:
        row[field] = float(form[field])

    for field, mapping in ENCODINGS.items():
        row[field] = mapping[form[field]]

    row["Age_group"] = AGE_GROUP_ENCODING[age_group]

    ordered = [row[feat] for feat in FEATURE_ORDER]
    return np.array(ordered, dtype=float).reshape(1, -1), age_group


@app.route("/", methods=["GET"])
def index():
    return render_template(
        "index.html",
        numeric_fields=NUMERIC_FIELDS,
        form_options=FORM_OPTIONS,
        result=None,
    )


@app.route("/predict", methods=["POST"])
def predict():
    features, age_group = build_feature_vector(request.form)

    pred = int(model.predict(features)[0])
    proba = model.predict_proba(features)[0]
    stayed_prob = float(proba[1]) * 100
    left_prob = float(proba[0]) * 100

    result = {
        "label": TARGET_LABELS[pred],
        "stayed_prob": round(stayed_prob, 1),
        "left_prob": round(left_prob, 1),
        "age_group": age_group,
    }

    return render_template(
        "index.html",
        numeric_fields=NUMERIC_FIELDS,
        form_options=FORM_OPTIONS,
        result=result,
        submitted_form=request.form,
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
