# Employee Attrition Predictor — Flask Deployment

A small Flask app that serves `best_catboost_model.pkl` behind a form UI.

## 1. Install & run

```bash
cd attrition_app
python -m venv venv && source venv/bin/activate   # optional
pip install -r requirements.txt

# copy your model into this folder if it isn't already here
cp /path/to/best_catboost_model.pkl .

python app.py
```

Then open http://localhost:5000

---

## 2. ⚠️ Two things you should fix before trusting predictions

Your pickle only contains the CatBoost model. Two pieces of information used
at *training* time never got saved, so I had to reconstruct them from the
public dataset documentation rather than your actual run. Please verify/fix
both — it's 5 minutes in Colab.

### A) The missing StandardScaler

In your notebook:

```python
X_train = scaler.fit_transform(x_train)
model4.fit(X_train, y_train)
...
pickle.dump(best_cat_model, open('best_catboost_model.pkl', 'wb'))   # scaler NOT saved
```

The model was trained on **scaled** features. Add this cell right after your
`scaler.fit_transform(x_train)` line (or re-run and add it at the end) and
download the resulting file into this app's folder as `scaler.pkl`:

```python
import pickle
pickle.dump(scaler, open('scaler.pkl', 'wb'))
```

If `scaler.pkl` is present next to `app.py`, the app will use it automatically.
If it's missing, the app still runs but shows a warning banner and predicts
on raw (unscaled) inputs, which will likely be inaccurate.

### B) Verify the feature order and category encodings

`app.py` builds a 23-value feature vector (`FEATURE_ORDER`) and encodes each
categorical field alphabetically (matching `sklearn.LabelEncoder`'s default
behavior). I reconstructed this from:
- your notebook's `categorical_cols` list and `pd.cut(...)` bins,
- the public description of the `stealthtechnologies/employee-attrition-dataset`
  Kaggle dataset (I don't have access to your actual `train.csv`).

To confirm it's exactly right, add this cell in your notebook right after
cell 18 (`x = pd.get_dummies(x, drop_first=True)`) and compare the printed
list to `FEATURE_ORDER` in `app.py`:

```python
print(x.columns.tolist())
```

Also print the label mappings actually used, to compare against `ENCODINGS`
in `app.py`:

```python
from sklearn.preprocessing import LabelEncoder
for col in categorical_cols:
    le2 = LabelEncoder()
    le2.fit(df_original[col])  # the column BEFORE it was overwritten with codes
    print(col, dict(zip(le2.classes_, le2.transform(le2.classes_))))
```

(You'll need to reload the raw CSV or keep a copy before the encoding loop
overwrites `df[col]` in place, since your current notebook encodes in place
and doesn't retain the original label→code mapping.)

If either list differs from what's in `app.py`, just edit `FEATURE_ORDER` /
`ENCODINGS` at the top of `app.py` to match — everything else works unchanged.

---

## 3. File overview

```
attrition_app/
├── app.py                  # Flask routes + preprocessing + inference
├── best_catboost_model.pkl # your trained model (copy it in)
├── scaler.pkl              # optional — add this, see section 2A
├── requirements.txt
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## 4. Deploying

Any standard Flask host works (Render, Railway, PythonAnywhere, a VM, etc.).
For production, run behind gunicorn instead of the Flask dev server:

```bash
pip install gunicorn
gunicorn -w 2 -b 0.0.0.0:8000 app:app
```
